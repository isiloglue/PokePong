/**
 * Das Paket enthält die PokePong Klassen Für das Poke-Pong spiel
 * Hier werden die alle  methoden, packungen und interfaces definiert.
 *  Es enthält Controller, Model und View packages und eine Main Klasse das PokePong stellt Packung bereit zu ein Pong spiel interagieren.
 * @author Elif BIlge Isiloglu
 */

package PokePongPackage;