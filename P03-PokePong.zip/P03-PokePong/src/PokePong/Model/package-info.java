
/**
 * Das Paket enthält die Model-Klassen für das Pong-Spiel.
 * Hier werden die Datenmodelle, Spieler, der Ball,Size,ort und andere spielbezogene Logik definiert.
 * @author Elif Bilge Isiloglu
 */
package PokePong.Model;