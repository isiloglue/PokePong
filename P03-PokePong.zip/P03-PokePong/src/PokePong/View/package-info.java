/**
 *Das Paket enthält die View Klassen Für das Poke-Pong spiel
 * Hier werden die Anzeigeimplemtierung definiert
 * Das Interface "View" stellt Methoden bereit, um die Anzeige zu definieren.
 * @author Elif Bilge Isiloglu
 */
package PokePong.View;