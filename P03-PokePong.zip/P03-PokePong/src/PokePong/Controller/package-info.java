/**
 * Das Paket enthält die Controller Klassen Für das Poke-Pong spiel
 * Hier werden die Steuerungselemente  definiert.
 * Das Interface "Controller" stellt Methoden bereit, um das Spiel zu steuern mit Model und View zu interagieren
 * @author Elif BIlge Isiloglu
 */
package PokePong.Controller;